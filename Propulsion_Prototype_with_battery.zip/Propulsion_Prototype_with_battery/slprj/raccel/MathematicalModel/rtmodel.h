#ifndef rtmodel_h_
#define rtmodel_h_
#include "MathematicalModel.h"
#define GRTINTERFACE 1
#endif
