#include "rtwtypes.h"
#include "rtGetInf.h"
real_T rtGetInf ( void ) { return rtInf ; } real32_T rtGetInfF ( void ) {
return rtInfF ; } real_T rtGetMinusInf ( void ) { return rtMinusInf ; }
real32_T rtGetMinusInfF ( void ) { return rtMinusInfF ; }
