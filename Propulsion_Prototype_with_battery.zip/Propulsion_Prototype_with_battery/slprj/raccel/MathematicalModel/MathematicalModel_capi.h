#ifndef MathematicalModel_capi_h_
#define MathematicalModel_capi_h_
#include "MathematicalModel.h"
extern void MathematicalModel_InitializeDataMapInfo ( void ) ;
#endif
