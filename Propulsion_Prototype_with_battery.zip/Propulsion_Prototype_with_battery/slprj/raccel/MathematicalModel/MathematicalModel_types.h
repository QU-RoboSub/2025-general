#ifndef MathematicalModel_types_h_
#define MathematicalModel_types_h_
#include "rtwtypes.h"
#include "MW_SVD.h"
#ifndef struct_tag_nECYgglEnyn3A1gAtJWnUE
#define struct_tag_nECYgglEnyn3A1gAtJWnUE
struct tag_nECYgglEnyn3A1gAtJWnUE { boolean_T matlabCodegenIsDeleted ;
int32_T isInitialized ; boolean_T isSetupComplete ; real_T SampleTime ; } ;
#endif
#ifndef typedef_luufrrieoo
#define typedef_luufrrieoo
typedef struct tag_nECYgglEnyn3A1gAtJWnUE luufrrieoo ;
#endif
#include "MW_SVD.h"
#ifndef struct_tag_7VFuPw0vSNrn5pRgG8Mc4C
#define struct_tag_7VFuPw0vSNrn5pRgG8Mc4C
struct tag_7VFuPw0vSNrn5pRgG8Mc4C { MW_Handle_Type MW_PWM_HANDLE ; } ;
#endif
#ifndef typedef_prym0aao01
#define typedef_prym0aao01
typedef struct tag_7VFuPw0vSNrn5pRgG8Mc4C prym0aao01 ;
#endif
#ifndef struct_tag_RWocY1aAVmuibq0rYX5t0G
#define struct_tag_RWocY1aAVmuibq0rYX5t0G
struct tag_RWocY1aAVmuibq0rYX5t0G { boolean_T matlabCodegenIsDeleted ;
int32_T isInitialized ; boolean_T isSetupComplete ; prym0aao01 PWMDriverObj ;
} ;
#endif
#ifndef typedef_hr3cntwh2j
#define typedef_hr3cntwh2j
typedef struct tag_RWocY1aAVmuibq0rYX5t0G hr3cntwh2j ;
#endif
#ifndef SS_UINT64
#define SS_UINT64 19
#endif
#ifndef SS_INT64
#define SS_INT64 20
#endif
typedef struct P_ P ;
#endif
