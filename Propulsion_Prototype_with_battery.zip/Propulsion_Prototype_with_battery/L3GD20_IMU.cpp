#include "C:\Users\research_bu\Documents\GitHub\2025-general\Propulsion_Prototype\L3GD20_IMU.h"
#include "arduino.h"
#include "L3GD20_IMU.h


#define IMUPIN SCL

void setupFunctionL3GD20_IMU(){
}

// X double [1,1]
// Y double [1,1]
// Z double [1,1]


void stepFunctionL3GD20_IMU(double * X,int size_vector_1,double * Y,int size_vector_2,double * Z,int size_vector_3){
  
}